package com.example.diaryclf;



import android.app.Fragment;
import android.app.FragmentManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import androidx.annotation.Nullable;
//import androidx.fragment.app.Fragment;//

import java.util.ArrayList;
import java.util.Map;


public class LeftFragment extends Fragment {

    private ListView listView;

    private SimpleAdapter listAdapter;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // TODO Auto-generated method stub

        View left = inflater.inflate(R.layout.left_layout, container, false);

        listView = left.findViewById(R.id.listView);
        ArrayList<Map<String, Object>> data;
        data = ((MainActivity)getActivity()).getData();

        listAdapter = new SimpleAdapter(getActivity(), data,
                R.layout.word, new String[]{"word"},
                new int[]{R.id.iword});

        listView.setAdapter(listAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                Map<String, Object> listItem = (Map<String, Object>) listView.getItemAtPosition(i);

                //FragmentManager fm = getActivity().getFragmentManager();
                ContentFragment contentFragment = (ContentFragment) getActivity().getSupportFragmentManager().findFragmentById(R.id.content_fragment);

                contentFragment.setMeanText((String) listItem.get("meaning"));
                contentFragment.setExampleText((String) listItem.get("example"));

            }
        });


        return left;
    }


    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


    }

    @Override
    public void onPause() {
        // TODO Auto-generated method stub
        super.onPause();
    }









}
