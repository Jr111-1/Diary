package com.example.diaryclf;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.res.Configuration;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private static String DB_NAME = "mydb";


    private DBOpenHelper dbOpenHelper;
    private SQLiteDatabase db;
    private Cursor cursor;
    private SimpleAdapter listAdapter;
    //private Adapter adapter;

    private ArrayList<Map<String, Object>> data;//用来存储单词信息
    private Map<String, Object> item;//用来存储ListView信息
    private ContentResolver resolver ;

    private EditText wordEdit;
    private EditText meanEdit;
    private EditText exampleEdit;
    private Button add, del, edit, query,Add;
    private ListView listView1;
    private ListView listView2;
    private TextView textView1;
    private TextView textView2;
    private PopupWindow popupWindow;

    private String name, meaning, example, delWord;
    private int id;


    private List<words> wordList = new ArrayList<>();

    private static final String WORD = "word" ;
    private static final String MEANING = "meaning" ;
    private static final String EXAMPLE = "example" ;
    private static final String AUTHORITY = "com.example.diarycontentprovider.provider" ;
    private static final Uri ALL_URI = Uri.parse("content://" + AUTHORITY + "/WordDiary") ;





    @SuppressLint("Range")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Configuration mConfiguration = this.getResources().getConfiguration();
        //获取屏幕方向
        int ori = mConfiguration.orientation;


        LeftFragment fragment1 = new LeftFragment();
        ContentFragment fragment2 = new ContentFragment();


        if (ori == mConfiguration.ORIENTATION_LANDSCAPE) {

            getSupportFragmentManager().beginTransaction().replace(R.id.a1,fragment2).commit();
            getSupportFragmentManager().beginTransaction().replace(R.id.a1,fragment1).commit();



        } else if (ori == mConfiguration.ORIENTATION_PORTRAIT) {

        }

        try {
            query = (Button) findViewById(R.id.bt_query);
            listView1 = findViewById(R.id.listview1);
            Add = (Button) findViewById(R.id.Addbtn);
            Add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    showAddPopuptWindow();
                }
            });

            //打开数据库

            dbOpenHelper = new DBOpenHelper(this,DB_NAME, null, 1);
            db = dbOpenHelper.getWritableDatabase();
            data = new ArrayList<Map<String, Object>>();
            dbFindAll();

            //showList();
            //registerForContextMenu(listView1);
            listView1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                    Map<String, Object> listItem = (Map<String, Object>) listView1.getItemAtPosition(i);
                    View popupWindow_view = getLayoutInflater().inflate(R.layout.updatepopupwindow, null,
                            false);
                    // 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度
                    popupWindow = new PopupWindow(popupWindow_view,LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, true);
                    popupWindow.setClippingEnabled(true);//
                    wordEdit = (EditText) popupWindow_view.findViewById(R.id.wordEdit);
                    meanEdit = (EditText) popupWindow_view.findViewById(R.id.meanEdit);
                    exampleEdit = (EditText) popupWindow_view.findViewById(R.id.exampleEdit);

                    wordEdit.setText((String) listItem.get("word"));
                    meanEdit.setText((String) listItem.get("meaning"));
                    exampleEdit.setText((String) listItem.get("example"));
                    delWord=wordEdit.getText().toString().trim();

                    edit = (Button) popupWindow_view.findViewById(R.id.bt_edit);
                    del = (Button) popupWindow_view.findViewById(R.id.bt_del);

                    edit.setOnClickListener(new Button.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            // TODO Auto-generated method stub
                            dbUpdate();
                            dbFindAll();
                        }
                    });

                    del.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            delDB();
                            dbFindAll();
                        }
                    });

                    View rootview = LayoutInflater.from(MainActivity.this).inflate(R.layout.activity_main, null);
                    popupWindow.showAtLocation(rootview, Gravity.CENTER, 0, 0);


                }
            });

        } catch (Exception e) {

        }








    }



    private void showList() {
        // TODO Auto-generated method stub

        listAdapter = new SimpleAdapter(this, data,
                R.layout.words, new String[]{"word", "meaning"},
                new int[]{R.id.iword, R.id.imean});

        listView1.setAdapter(listAdapter);
    }


    protected void addDB(){

        words word = new words();
        word.setName(wordEdit.getText().toString().trim());
        word.setMeaning(meanEdit.getText().toString().trim());
        word.setExample(exampleEdit.getText().toString().trim());

        ContentValues values = new ContentValues();

        values.put("name", word.getName());
        values.put("meaning", word.getMeaning());
        values.put("example", word.getExample());
        //将信息插入
        db.insert(dbOpenHelper.TB_name, null, values);
//        long rowId = db.insert(dbOpenHelper.TB_name, null, values);
//        if (rowId == -1)
//            Log.i("myDbDemo", "数据插入失败！");
//        else
//            Log.i("myDbDemo", "数据插入成功!" + rowId);

    }
    //读数据库
    protected void dbFindAll() {
        // TODO Auto-generated method stub
        data.clear();
        cursor = db.rawQuery("select * from WordDiary", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            String word = cursor.getString(1);
            String meaning = cursor.getString(2);
            String example = cursor.getString(3);
            item = new HashMap<String, Object>();
            item.put("word", word);
            item.put("meaning", meaning);
            item.put("example", example);
            data.add(item);
            cursor.moveToNext();

        }
        showList();
    }
    //删除方法
    protected void delDB(){

        db.execSQL("DELETE FROM WordDiary WHERE name = '"+delWord+"' ;");

    }


    protected void dbUpdate() {
        ContentValues values = new ContentValues();
        values.put("meaning", meanEdit.getText().toString().trim());
        values.put("example", exampleEdit.getText().toString().trim());
        String[]args={delWord};
        db.update(dbOpenHelper.TB_name, values, "name=?", args);
//        int i = db.update(dbOpenHelper.TB_name, values, "name=?", args);
//        if (i > 0)
//            Log.i("myDbDemo", "数据更新成功！");
//        else
//            Log.i("myDbDemo", "数据未更新");
    }








    protected void showAddPopuptWindow() {
        // TODO Auto-generated method stub
        // 获取自定义布局文件activity_popupwindow_left.xml的视图
        View popupWindow_view = getLayoutInflater().inflate(R.layout.addpopwindow, null,
                false);
        // 创建PopupWindow实例,200,LayoutParams.MATCH_PARENT分别是宽度和高度
        popupWindow = new PopupWindow(popupWindow_view,LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT, true);
        popupWindow.setClippingEnabled(true);//
        wordEdit = (EditText) popupWindow_view.findViewById(R.id.wordEdit);
        meanEdit = (EditText) popupWindow_view.findViewById(R.id.meanEdit);
        exampleEdit = (EditText) popupWindow_view.findViewById(R.id.exampleEdit);

        add = popupWindow_view.findViewById(R.id.bt_add);

        add.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                //添加数据
                addDB();
                //更新添加后的数据
                dbFindAll();

            }
        });

        View rootview = LayoutInflater.from(MainActivity.this).inflate(R.layout.activity_main, null);
        popupWindow.showAtLocation(rootview, Gravity.CENTER, 0, 0);

    }

    public  ArrayList<Map<String, Object>> getData(){

        return data;
    }


}